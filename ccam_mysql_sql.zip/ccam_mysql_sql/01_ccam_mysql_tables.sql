# MySQL dump 8.14
#
# Host: localhost    Database: CCAM
#--------------------------------------------------------
# Server version	3.23.39-log

#
# Table structure for table 'ACCES1'
#

CREATE TABLE ACCES1 (
  CODE char(1) NOT NULL default '',
  ACCES varchar(80) default NULL,
  LIBELLE varchar(255) default NULL,
  PRIMARY KEY  (CODE),
  KEY ACCES (ACCES)
) TYPE=MyISAM;

#
# Table structure for table 'ACCES2'
#

CREATE TABLE ACCES2 (
  PERE char(1) default NULL,
  LIBELLE varchar(150) default NULL,
  KEY PERE (PERE)
) TYPE=MyISAM;

#
# Table structure for table 'ACTES'
#

CREATE TABLE ACTES (
  CODE varchar(13) NOT NULL default '',
  LIBELLECOURT varchar(70) default NULL,
  TYPE char(1) default NULL,
  SEXE char(1) default NULL,
  DATECREATION varchar(8) default NULL,
  DATEFIN varchar(8) default NULL,
  ASSURANCE1 char(2) default NULL,
  ASSURANCE2 char(2) default NULL,
  ASSURANCE3 char(2) default NULL,
  ASSURANCE4 char(2) default NULL,
  ASSURANCE5 char(2) default NULL,
  ASSURANCE6 char(2) default NULL,
  ASSURANCE7 char(2) default NULL,
  ASSURANCE8 char(2) default NULL,
  ASSURANCE9 char(2) default NULL,
  ASSURANCE10 char(2) default NULL,
  DEPLACEMENT char(1) default NULL,
  ARBORESCENCE1 varchar(6) default NULL,
  ARBORESCENCE2 varchar(6) default NULL,
  ARBORESCENCE3 varchar(6) default NULL,
  ARBORESCENCE4 varchar(6) default NULL,
  ARBORESCENCE5 varchar(6) default NULL,
  ARBORESCENCE6 varchar(6) default NULL,
  ARBORESCENCE7 varchar(6) default NULL,
  ARBORESCENCE8 varchar(6) default NULL,
  ARBORESCENCE9 varchar(6) default NULL,
  ARBORESCENCE10 varchar(6) default NULL,
  PLACEARBORESCENCE varchar(12) default NULL,
  CODESTRUCTURE varchar(13) default NULL,
  CODEPRECEDENT varchar(13) default NULL,
  CODESUIVANT varchar(13) default NULL,
  LIBELLELONG text,
  CCAM26 varchar(8) default NULL,
  CCAM27 varchar(8) default NULL,
  CCAM28 varchar(8) default NULL,
  CCAM22 char(1) default NULL,
  CCAM24 char(1) default NULL,
  CCAM25 varchar(5) default NULL,
  CCAM31 varchar(20) default NULL,
  CCAM34 varchar(10) default NULL,
  PRIMARY KEY  (CODE)
) TYPE=MyISAM;

#
# Table structure for table 'ACTION1'
#

CREATE TABLE ACTION1 (
  VERBE varchar(20) NOT NULL default '',
  CODE char(1) default NULL,
  LIBELLE varchar(255) default NULL,
  PRIMARY KEY  (VERBE),
  KEY CODE (CODE)
) TYPE=MyISAM;

#
# Table structure for table 'ACTION2'
#

CREATE TABLE ACTION2 (
  VERBE varchar(30) default NULL,
  CODE char(1) default NULL,
  SUBSTANTIF varchar(20) default NULL,
  KEY ACTION (VERBE),
  KEY CODE (CODE),
  KEY VERBE (SUBSTANTIF)
) TYPE=MyISAM;

#
# Table structure for table 'ACTIVITE'
#

CREATE TABLE ACTIVITE (
  CODE char(1) NOT NULL default '',
  LIBELLE varchar(100) default NULL,
  PRIMARY KEY  (CODE)
) TYPE=MyISAM;

#
# Table structure for table 'ACTIVITEACTE'
#

CREATE TABLE ACTIVITEACTE (
  CODEACTE char(13) default NULL,
  ACTIVITE char(1) default NULL,
  KEY CODEACTE (CODEACTE),
  KEY ACTIVITE (ACTIVITE)
) TYPE=MyISAM;

#
# Table structure for table 'ARBORESCENCE'
#

CREATE TABLE ARBORESCENCE (
  CODEMENU varchar(6) NOT NULL default '',
  CODEPERE varchar(6) default NULL,
  RANG varchar(6) default NULL,
  LIBELLE text,
  PRIMARY KEY  (CODEMENU),
  KEY CODEPERE (CODEPERE),
  KEY RANG (RANG)
) TYPE=MyISAM;

#
# Table structure for table 'ASSOCIABILITE'
#

CREATE TABLE ASSOCIABILITE (
  CODEACTE char(13) default NULL,
  ACTIVITE char(1) default NULL,
  DATEEFFET char(8) default NULL,
  ACTEASSO char(13) default NULL,
  ACTIVITEASSO char(1) default NULL,
  REGLE char(1) default NULL,
  KEY CODEACTE (CODEACTE),
  KEY ACTIVITE (ACTIVITE)
) TYPE=MyISAM;

#
# Table structure for table 'ASSOCIATION'
#

CREATE TABLE ASSOCIATION (
  CODE char(1) NOT NULL default '',
  DATEDEBUT char(8) default NULL,
  DATEFIN char(8) default NULL,
  COEFFICIENT char(4) default NULL,
  PRIMARY KEY  (CODE)
) TYPE=MyISAM;

#
# Table structure for table 'INCOMPATIBILITE'
#

CREATE TABLE INCOMPATIBILITE (
  CODEACTE char(13) default NULL,
  DATEEFFET char(8) default NULL,
  INCOMPATIBLE char(13) default NULL,
  KEY CODEACTE (CODEACTE)
) TYPE=MyISAM;

#
# Table structure for table 'MODIFICATEUR'
#

CREATE TABLE MODIFICATEUR (
  CODE char(1) NOT NULL default '',
  LIBELLE varchar(100) default NULL,
  PRIMARY KEY  (CODE)
) TYPE=MyISAM;

#
# Table structure for table 'MODIFICATEURACTE'
#

CREATE TABLE MODIFICATEURACTE (
  CODEACTE varchar(13) default NULL,
  CODEACTIVITE char(1) default NULL,
  DATEEFFET varchar(8) default NULL,
  MODIFICATEUR char(1) default NULL,
  KEY CODEACTE (CODEACTE),
  KEY CODEACTIVITE (CODEACTIVITE),
  KEY MODIFICATEUR (MODIFICATEUR)
) TYPE=MyISAM;

#
# Table structure for table 'NOTES'
#

CREATE TABLE NOTES (
  CODEACTE varchar(13) default NULL,
  TYPE char(2) default NULL,
  TEXTE text,
  KEY CODEACTE (CODEACTE),
  KEY TYPE (TYPE)
) TYPE=MyISAM;

#
# Table structure for table 'NOTESARBORESCENCE'
#

CREATE TABLE NOTESARBORESCENCE (
  CODEMENU varchar(6) default NULL,
  TYPE char(2) default NULL,
  TEXTE text,
  KEY CODEMENU (CODEMENU)
) TYPE=MyISAM;

#
# Table structure for table 'PHASE'
#

CREATE TABLE PHASE (
  CODE char(1) NOT NULL default '',
  LIBELLE varchar(80) default NULL,
  PRIMARY KEY  (CODE)
) TYPE=MyISAM;

#
# Table structure for table 'PHASEACTE'
#

CREATE TABLE PHASEACTE (
  CODEACTE char(13) default NULL,
  ACTIVITE char(1) default NULL,
  PHASE char(1) default NULL,
  NBDENTS char(2) default NULL,
  AGEMINI char(3) default NULL,
  AGEMAXI char(3) default NULL,
  ICR char(4) default NULL,
  CLASSANT char(1) default NULL
) TYPE=MyISAM;

#
# Table structure for table 'PROCEDURES'
#

CREATE TABLE PROCEDURES (
  CODEACTE char(13) default NULL,
  DATEEFFET char(8) default NULL,
  CODEPROCEDURE char(13) default NULL,
  KEY CODEACTE (CODEACTE)
) TYPE=MyISAM;

#
# Table structure for table 'TOPOGRAPHIE1'
#

CREATE TABLE TOPOGRAPHIE1 (
  CODE char(1) NOT NULL default '',
  LIBELLE varchar(80) default NULL,
  PRIMARY KEY  (CODE)
) TYPE=MyISAM;

#
# Table structure for table 'TOPOGRAPHIE2'
#

CREATE TABLE TOPOGRAPHIE2 (
  CODE char(2) NOT NULL default '',
  PERE char(1) default NULL,
  LIBELLE varchar(150) default NULL,
  PRIMARY KEY  (CODE),
  KEY PERE (PERE)
) TYPE=MyISAM;

#
# Table structure for table 'TYPENOTE'
#

CREATE TABLE TYPENOTE (
  CODE char(2) NOT NULL default '',
  LIBELLE varchar(100) default NULL,
  PRIMARY KEY  (CODE)
) TYPE=MyISAM;

