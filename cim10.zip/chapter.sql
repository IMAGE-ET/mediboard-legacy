# phpMyAdmin SQL Dump
# version 2.5.3
# http://www.phpmyadmin.net
#
# Host: localhost
# Generation Time: Aug 12, 2004 at 04:45 PM
# Server version: 4.0.15
# PHP Version: 4.3.3
# 
# Database : `cim10`
# 

#
# Dumping data for table `chapter`
#

INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (1, 1, 'I');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (2, 932, 'II');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (3, 1805, 'III');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (4, 2003, 'IV');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (5, 2422, 'V');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (6, 2901, 'VI');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (7, 3299, 'VII');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (8, 3618, 'VIII');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (9, 3758, 'IX');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (10, 4223, 'X');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (11, 4510, 'XI');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (12, 4997, 'XII');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (13, 5401, 'XIII');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (14, 6043, 'XIV');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (15, 6556, 'XV');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (16, 7052, 'XVI');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (17, 7449, 'XVII');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (18, 8171, 'XVIII');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (19, 8571, 'XIX');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (20, 10053, 'XX');
INSERT INTO `chapter` (`chap`, `SID`, `rom`) VALUES (21, 11603, 'XXI');
