# phpMyAdmin SQL Dump
# version 2.5.3
# http://www.phpmyadmin.net
#
# Host: localhost
# Generation Time: Aug 12, 2004 at 04:41 PM
# Server version: 4.0.15
# PHP Version: 4.3.3
# 
# Database : `cim10`
# 

# --------------------------------------------------------

#
# Table structure for table `chapter`
#
# Creation: Aug 12, 2004 at 09:35 AM
# Last update: Aug 12, 2004 at 09:35 AM
#

CREATE TABLE `chapter` (
  `chap` bigint(20) NOT NULL default '0',
  `SID` int(11) NOT NULL default '0',
  `rom` varchar(5) NOT NULL default '',
  PRIMARY KEY  (`chap`),
  KEY `SID` (`SID`)
) TYPE=MyISAM COMMENT='Table description and capacity';

# --------------------------------------------------------

#
# Table structure for table `common`
#
# Creation: Aug 10, 2004 at 11:39 AM
# Last update: Aug 10, 2004 at 12:40 PM
#

CREATE TABLE `common` (
  `SID` bigint(20) NOT NULL auto_increment,
  `male` tinyint(4) NOT NULL default '0',
  `female` tinyint(4) NOT NULL default '0',
  `sequella` tinyint(4) NOT NULL default '0',
  `post` tinyint(4) NOT NULL default '0',
  `second` tinyint(4) NOT NULL default '0',
  `nocode` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`SID`)
) TYPE=MyISAM COMMENT='Common attributes of certain codes' AUTO_INCREMENT=12312 ;

# --------------------------------------------------------

#
# Table structure for table `dagstar`
#
# Creation: Aug 12, 2004 at 09:36 AM
# Last update: Aug 12, 2004 at 09:36 AM
# Last check: Aug 12, 2004 at 09:36 AM
#

CREATE TABLE `dagstar` (
  `SID` bigint(20) NOT NULL default '0',
  `LID` bigint(20) NOT NULL default '0',
  `assoc` bigint(20) NOT NULL default '0',
  `daget` char(1) NOT NULL default '',
  `plus` tinyint(4) NOT NULL default '0',
  KEY `SID` (`SID`),
  KEY `LID` (`LID`)
) TYPE=MyISAM COMMENT='Dags and stars structure and links to libelles';

# --------------------------------------------------------

#
# Table structure for table `descr`
#
# Creation: Aug 10, 2004 at 12:26 PM
# Last update: Aug 10, 2004 at 12:42 PM
#

CREATE TABLE `descr` (
  `SID` bigint(20) NOT NULL default '0',
  `LID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`SID`,`LID`)
) TYPE=MyISAM COMMENT='Links to descriptor libelles';

# --------------------------------------------------------

#
# Table structure for table `exclude`
#
# Creation: Aug 12, 2004 at 09:37 AM
# Last update: Aug 12, 2004 at 09:37 AM
# Last check: Aug 12, 2004 at 09:37 AM
#

CREATE TABLE `exclude` (
  `SID` int(11) NOT NULL default '0',
  `excl` int(11) NOT NULL default '0',
  `plus` tinyint(4) NOT NULL default '0',
  `LID` bigint(20) NOT NULL default '0',
  `daget` char(1) NOT NULL default '',
  KEY `SID` (`SID`),
  KEY `excl` (`excl`)
) TYPE=MyISAM COMMENT='Exclusion structure and links to exclusion libelles';

# --------------------------------------------------------

#
# Table structure for table `glossaire`
#
# Creation: Aug 10, 2004 at 12:27 PM
# Last update: Aug 10, 2004 at 12:43 PM
#

CREATE TABLE `glossaire` (
  `SID` bigint(20) NOT NULL default '0',
  `MID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`SID`,`MID`)
) TYPE=MyISAM COMMENT='Links to glossary memos';

# --------------------------------------------------------

#
# Table structure for table `html`
#
# Creation: Aug 10, 2004 at 11:58 AM
# Last update: Aug 10, 2004 at 12:44 PM
#

CREATE TABLE `html` (
  `ref` varchar(20) NOT NULL default '',
  `FR` text NOT NULL,
  `EN` text NOT NULL,
  `GE` text NOT NULL,
  PRIMARY KEY  (`ref`)
) TYPE=MyISAM COMMENT='HTML table pages in different languages';

# --------------------------------------------------------

#
# Table structure for table `include`
#
# Creation: Aug 10, 2004 at 12:27 PM
# Last update: Aug 10, 2004 at 12:45 PM
#

CREATE TABLE `include` (
  `SID` int(11) NOT NULL default '0',
  `LID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`SID`,`LID`)
) TYPE=MyISAM COMMENT='Links to inclusion libelles';

# --------------------------------------------------------

#
# Table structure for table `indir`
#
# Creation: Aug 10, 2004 at 12:27 PM
# Last update: Aug 10, 2004 at 12:43 PM
#

CREATE TABLE `indir` (
  `SID` int(11) NOT NULL default '0',
  `LID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`SID`,`LID`)
) TYPE=MyISAM COMMENT='Links to indirect exclusion libelles';

# --------------------------------------------------------

#
# Table structure for table `libelle`
#
# Creation: Aug 12, 2004 at 09:40 AM
# Last update: Aug 12, 2004 at 09:40 AM
# Last check: Aug 12, 2004 at 09:40 AM
#

CREATE TABLE `libelle` (
  `LID` bigint(20) NOT NULL auto_increment,
  `SID` bigint(20) NOT NULL default '0',
  `source` char(1) NOT NULL default '',
  `valid` tinyint(4) NOT NULL default '0',
  `libelle` varchar(255) NOT NULL default '',
  `FR_OMS` varchar(255) NOT NULL default '',
  `EN_OMS` varchar(255) NOT NULL default '',
  `GE_DIMDI` varchar(255) NOT NULL default '',
  `GE_AUTO` varchar(255) NOT NULL default '',
  `FR_CHRONOS` varchar(255) NOT NULL default '',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `author` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`LID`),
  KEY `SID` (`SID`),
  KEY `SID_2` (`SID`)
) TYPE=MyISAM COMMENT='Table of libelles' AUTO_INCREMENT=70601 ;

# --------------------------------------------------------

#
# Table structure for table `master`
#
# Creation: Aug 12, 2004 at 09:40 AM
# Last update: Aug 12, 2004 at 09:40 AM
# Last check: Aug 12, 2004 at 09:40 AM
#

CREATE TABLE `master` (
  `SID` bigint(20) NOT NULL auto_increment,
  `code` varchar(10) NOT NULL default '',
  `sort` varchar(10) NOT NULL default '',
  `abbrev` varchar(10) NOT NULL default '',
  `level` char(1) NOT NULL default '',
  `type` char(1) NOT NULL default '',
  `id1` bigint(20) NOT NULL default '0',
  `id2` bigint(20) NOT NULL default '0',
  `id3` bigint(20) NOT NULL default '0',
  `id4` bigint(20) NOT NULL default '0',
  `id5` bigint(20) NOT NULL default '0',
  `id6` bigint(20) NOT NULL default '0',
  `id7` bigint(20) NOT NULL default '0',
  `valid` tinyint(4) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `author` varchar(10) NOT NULL default '',
  `comment` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`SID`),
  KEY `code` (`code`),
  KEY `abbrev` (`abbrev`)
) TYPE=MyISAM COMMENT='Hierarchical structure of ICD10 and code declaration' AUTO_INCREMENT=19551 ;

# --------------------------------------------------------

#
# Table structure for table `memo`
#
# Creation: Aug 12, 2004 at 09:42 AM
# Last update: Aug 12, 2004 at 09:42 AM
# Last check: Aug 12, 2004 at 09:42 AM
#

CREATE TABLE `memo` (
  `MID` bigint(20) NOT NULL auto_increment,
  `SID` bigint(20) NOT NULL default '0',
  `source` char(1) NOT NULL default '',
  `valid` varchar(50) NOT NULL default '',
  `memo` text NOT NULL,
  `FR_OMS` text NOT NULL,
  `EN_OMS` text NOT NULL,
  `GE_DIMDI` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `author` varchar(10) NOT NULL default '',
  `comment` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`MID`),
  KEY `SID` (`SID`)
) TYPE=MyISAM COMMENT='Table of memo texts' AUTO_INCREMENT=619 ;

# --------------------------------------------------------

#
# Table structure for table `note`
#
# Creation: Aug 10, 2004 at 12:25 PM
# Last update: Aug 10, 2004 at 03:07 PM
#

CREATE TABLE `note` (
  `SID` bigint(20) NOT NULL default '0',
  `MID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`SID`,`MID`)
) TYPE=MyISAM COMMENT='Links to note memos';

# --------------------------------------------------------

#
# Table structure for table `refer`
#
# Creation: Aug 10, 2004 at 12:30 PM
# Last update: Aug 10, 2004 at 03:07 PM
#

CREATE TABLE `refer` (
  `SID` bigint(20) NOT NULL default '0',
  `LID` bigint(20) NOT NULL default '0',
  `ref` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`SID`,`LID`)
) TYPE=MyISAM COMMENT='Links to references for specific tables and texts';

# --------------------------------------------------------

#
# Table structure for table `system`
#
# Creation: Aug 10, 2004 at 12:31 PM
# Last update: Aug 10, 2004 at 03:07 PM
#

CREATE TABLE `system` (
  `SID` bigint(20) NOT NULL default '0',
  `LID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`SID`,`LID`)
) TYPE=MyISAM COMMENT='Links to systematic libelles';
